import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Hero from "../components/Hero";
import Services from "../components/Services";
import BeforeAfter from "../components/BeforeAfter";
import WhyChoose from "../components/WhyChoose";
import Portfolio from "../components/Portfolio";
import Pricing from "../components/Pricing";
import Process from "../components/Process";
import Founder from "../components/Founder";
import Testimonials from "../components/Testimonials";
import Contact from "../components/Contact";
import FinalCTA from "../components/FinalCTA";

export default function Home() {
  const { hash } = useLocation();
  const navigate = useNavigate();

  // Scroll to a section if arriving with a hash (e.g. from another route)
  useEffect(() => {
    if (hash) {
      const id = hash.replace("#", "");
      requestAnimationFrame(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
      });
    }
  }, [hash]);

  const scrollTo = (sel: string) =>
    document.querySelector(sel)?.scrollIntoView({ behavior: "smooth" });

  return (
    <main>
      <Hero
        onPrimary={() => navigate("/intake?plan=business")}
        onSecondary={() => scrollTo("#work")}
      />
      <Services />
      <BeforeAfter />
      <WhyChoose />
      <Portfolio />
      <Pricing />
      <Process />
      <Founder />
      <Testimonials />
      <Contact />
      <FinalCTA />
    </main>
  );
}
