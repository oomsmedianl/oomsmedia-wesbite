import { useCallback, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  UploadCloud,
  X,
  Building2,
  Palette,
  Lightbulb,
  Package,
  UserRound,
  CheckCircle2,
} from "lucide-react";
import { PRICING, SITE } from "../lib/site";

type FileItem = { name: string; size: number; url: string; isImage: boolean };

type Data = {
  plan: string;
  businessName: string;
  niche: string;
  audience: string;
  styles: string[];
  colors: string[];
  pages: string[];
  booking: string;
  inspiration: string;
  wishes: string;
  files: FileItem[];
  contactName: string;
  email: string;
  phone: string;
};

const STYLE_OPTIONS = [
  "Minimal & clean",
  "Bold & premium",
  "Cinematic / dark",
  "Warm & friendly",
  "Corporate & trusted",
  "Playful & modern",
];
const COLOR_OPTIONS = [
  { name: "Navy & Cyan", from: "#2f6bff", to: "#2fe3ff" },
  { name: "Black & Gold", from: "#1a1a1a", to: "#d4af37" },
  { name: "Emerald", from: "#065f46", to: "#34d399" },
  { name: "Sunset", from: "#b91c1c", to: "#f59e0b" },
  { name: "Purple", from: "#5b21b6", to: "#c084fc" },
  { name: "Mono / Grayscale", from: "#1f2937", to: "#9ca3af" },
];
const PAGE_OPTIONS = [
  "Home",
  "About",
  "Services",
  "Portfolio",
  "Pricing",
  "Contact",
  "Blog",
  "Booking",
  "Webshop",
];

const STEPS = [
  { key: "plan", title: "Package", icon: Package },
  { key: "business", title: "Business", icon: Building2 },
  { key: "vision", title: "Vision", icon: Palette },
  { key: "inspo", title: "Inspiration", icon: Lightbulb },
  { key: "details", title: "Details", icon: UserRound },
];

export default function Intake() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const initialPlan = params.get("plan") || "business";

  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const [data, setData] = useState<Data>({
    plan: PRICING.some((p) => p.id === initialPlan) ? initialPlan : "business",
    businessName: "",
    niche: "",
    audience: "",
    styles: [],
    colors: [],
    pages: ["Home", "About", "Contact"],
    booking: "unsure",
    inspiration: "",
    wishes: "",
    files: [],
    contactName: "",
    email: "",
    phone: "",
  });

  const set = (patch: Partial<Data>) => setData((d) => ({ ...d, ...patch }));
  const toggle = (key: "styles" | "colors" | "pages", value: string) =>
    setData((d) => ({
      ...d,
      [key]: d[key].includes(value)
        ? d[key].filter((v) => v !== value)
        : [...d[key], value],
    }));

  const addFiles = useCallback((list: FileList | null) => {
    if (!list) return;
    const items: FileItem[] = Array.from(list).map((f) => ({
      name: f.name,
      size: f.size,
      url: URL.createObjectURL(f),
      isImage: f.type.startsWith("image/"),
    }));
    setData((d) => ({ ...d, files: [...d.files, ...items] }));
  }, []);

  const removeFile = (url: string) =>
    setData((d) => ({ ...d, files: d.files.filter((f) => f.url !== url) }));

  const canContinue = useMemo(() => {
    switch (step) {
      case 0:
        return !!data.plan;
      case 1:
        return data.businessName.trim() && data.niche.trim();
      case 2:
        return data.styles.length > 0 && data.pages.length > 0;
      case 4:
        return data.contactName.trim() && /\S+@\S+\.\S+/.test(data.email);
      default:
        return true;
    }
  }, [step, data]);

  const go = (next: number) => {
    setDir(next > step ? 1 : -1);
    setStep(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const submit = () => {
    const plan = PRICING.find((p) => p.id === data.plan);
    const summary = [
      `NEW PROJECT INTAKE — ${SITE.name}`,
      ``,
      `Package: ${plan?.name} (${plan?.price})`,
      `Business: ${data.businessName}`,
      `Niche: ${data.niche}`,
      `Target audience: ${data.audience}`,
      `Preferred style: ${data.styles.join(", ")}`,
      `Colors: ${data.colors.join(", ") || "open to suggestions"}`,
      `Pages: ${data.pages.join(", ")}`,
      `Booking system: ${data.booking}`,
      `Inspiration: ${data.inspiration}`,
      `Extra wishes: ${data.wishes}`,
      `Files: ${data.files.map((f) => f.name).join(", ") || "none attached here"}`,
      ``,
      `Contact: ${data.contactName}`,
      `Email: ${data.email}`,
      `Phone: ${data.phone}`,
    ].join("\n");
    window.location.href = `${SITE.emailHref}?subject=${encodeURIComponent(
      `Project intake — ${data.businessName || "new client"}`
    )}&body=${encodeURIComponent(summary)}`;
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* atmosphere */}
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute -left-40 top-0 h-[40rem] w-[40rem] rounded-full bg-electric/20 blur-[150px] animate-drift" />
        <div className="absolute -right-32 bottom-0 h-[36rem] w-[36rem] rounded-full bg-cyan/15 blur-[150px] animate-float-slow" />
        <div className="absolute inset-0 bg-grid-faint bg-[size:64px_64px] [mask-image:radial-gradient(70%_60%_at_50%_20%,#000,transparent)]" />
      </div>

      {/* header */}
      <header className="relative z-10">
        <div className="container-x flex items-center justify-between py-5">
          <Link to="/" className="flex items-center gap-2">
            <img src="/assets/logo-full.png" alt={SITE.name} className="h-7 w-auto" />
          </Link>
          <Link
            to="/"
            className="flex items-center gap-1.5 text-sm text-muted transition-colors hover:text-mist"
          >
            <ArrowLeft size={15} /> Back to site
          </Link>
        </div>
      </header>

      <div className="container-x relative z-10 pb-24 pt-4">
        {submitted ? (
          <Success name={data.contactName} onHome={() => navigate("/")} />
        ) : (
          <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
            {/* Rail */}
            <aside className="lg:sticky lg:top-8 lg:self-start">
              <div className="glass-strong rounded-3xl p-6">
                <p className="eyebrow">Project intake</p>
                <h1 className="mt-2 font-display text-2xl font-semibold leading-tight">
                  Let's design your{" "}
                  <span className="text-gradient-cyan">dream website</span>
                </h1>
                <p className="mt-2 text-sm text-muted">
                  Takes about 2 minutes. The more you share, the sharper your
                  quote.
                </p>

                <ol className="mt-7 space-y-1.5">
                  {STEPS.map((s, i) => {
                    const Icon = s.icon;
                    const active = i === step;
                    const done = i < step;
                    return (
                      <li key={s.key}>
                        <button
                          onClick={() => i < step && go(i)}
                          disabled={i > step}
                          className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-colors ${
                            active
                              ? "bg-white/5 text-mist"
                              : done
                              ? "text-mist/70 hover:bg-white/5"
                              : "text-muted/60"
                          }`}
                        >
                          <span
                            className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg ${
                              active
                                ? "bg-gradient-to-br from-cyan to-electric text-ink"
                                : done
                                ? "bg-cyan/20 text-cyan"
                                : "bg-white/5"
                            }`}
                          >
                            {done ? <Check size={14} /> : <Icon size={14} />}
                          </span>
                          {s.title}
                        </button>
                      </li>
                    );
                  })}
                </ol>
              </div>
            </aside>

            {/* Step content */}
            <div>
              {/* progress bar (mobile-friendly) */}
              <div className="mb-6">
                <div className="flex items-center justify-between text-xs text-muted">
                  <span className="font-mono">
                    Step {step + 1} / {STEPS.length}
                  </span>
                  <span>{STEPS[step].title}</span>
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-cyan to-electric"
                    animate={{ width: `${progress}%` }}
                    transition={{ ease: [0.22, 1, 0.36, 1], duration: 0.5 }}
                  />
                </div>
              </div>

              <div className="glass-strong rounded-3xl p-6 shadow-glass sm:p-8">
                <AnimatePresence mode="wait" custom={dir}>
                  <motion.div
                    key={step}
                    custom={dir}
                    initial={{ opacity: 0, x: dir * 40 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: dir * -40 }}
                    transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  >
                    {step === 0 && (
                      <Step
                        title="Choose your package"
                        hint="You can change this later — it just helps us scope your quote."
                      >
                        <div className="grid gap-4 sm:grid-cols-3">
                          {PRICING.map((p) => {
                            const sel = data.plan === p.id;
                            return (
                              <button
                                key={p.id}
                                onClick={() => set({ plan: p.id })}
                                className={`rounded-2xl border p-5 text-left transition-all ${
                                  sel
                                    ? "border-cyan/60 bg-cyan/5 shadow-glow"
                                    : "border-white/10 bg-white/[0.03] hover:border-white/25"
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-display font-semibold">
                                    {p.name}
                                  </span>
                                  <span
                                    className={`grid h-5 w-5 place-items-center rounded-full border ${
                                      sel
                                        ? "border-cyan bg-cyan text-ink"
                                        : "border-white/25"
                                    }`}
                                  >
                                    {sel && <Check size={12} />}
                                  </span>
                                </div>
                                <p className="mt-2 text-sm text-gradient-cyan">
                                  {p.price}
                                </p>
                                <p className="mt-1 text-xs text-muted">
                                  {p.tagline}
                                </p>
                              </button>
                            );
                          })}
                        </div>
                      </Step>
                    )}

                    {step === 1 && (
                      <Step
                        title="Tell us about your business"
                        hint="The basics — so we understand who we're designing for."
                      >
                        <div className="space-y-5">
                          <Input
                            label="Business name"
                            value={data.businessName}
                            onChange={(v) => set({ businessName: v })}
                            placeholder="e.g. Atlas Fitness"
                          />
                          <Input
                            label="Niche / industry"
                            value={data.niche}
                            onChange={(v) => set({ niche: v })}
                            placeholder="e.g. Personal training studio"
                          />
                          <TextArea
                            label="Who is your target audience?"
                            value={data.audience}
                            onChange={(v) => set({ audience: v })}
                            placeholder="e.g. Busy professionals aged 25–45 in the region looking to get fit."
                          />
                        </div>
                      </Step>
                    )}

                    {step === 2 && (
                      <Step
                        title="Your vision"
                        hint="Pick what feels right. There are no wrong answers."
                      >
                        <div className="space-y-7">
                          <Group label="Preferred style (pick any)">
                            <ChipGroup
                              options={STYLE_OPTIONS}
                              selected={data.styles}
                              onToggle={(v) => toggle("styles", v)}
                            />
                          </Group>

                          <Group label="Color direction">
                            <div className="flex flex-wrap gap-3">
                              {COLOR_OPTIONS.map((c) => {
                                const sel = data.colors.includes(c.name);
                                return (
                                  <button
                                    key={c.name}
                                    onClick={() => toggle("colors", c.name)}
                                    className={`flex items-center gap-2 rounded-full border py-1.5 pl-1.5 pr-4 text-sm transition-all ${
                                      sel
                                        ? "border-cyan/60 bg-cyan/5"
                                        : "border-white/10 hover:border-white/25"
                                    }`}
                                  >
                                    <span
                                      className="h-6 w-6 rounded-full"
                                      style={{
                                        background: `linear-gradient(135deg, ${c.from}, ${c.to})`,
                                      }}
                                    />
                                    {c.name}
                                  </button>
                                );
                              })}
                            </div>
                          </Group>

                          <Group label="Pages you need">
                            <ChipGroup
                              options={PAGE_OPTIONS}
                              selected={data.pages}
                              onToggle={(v) => toggle("pages", v)}
                            />
                          </Group>

                          <Group label="Need a booking system?">
                            <div className="flex flex-wrap gap-2">
                              {[
                                ["yes", "Yes please"],
                                ["no", "Not needed"],
                                ["unsure", "Not sure yet"],
                              ].map(([val, label]) => (
                                <button
                                  key={val}
                                  onClick={() => set({ booking: val })}
                                  className={`rounded-full border px-5 py-2 text-sm transition-all ${
                                    data.booking === val
                                      ? "border-cyan/60 bg-cyan/5 text-mist"
                                      : "border-white/10 text-muted hover:border-white/25"
                                  }`}
                                >
                                  {label}
                                </button>
                              ))}
                            </div>
                          </Group>
                        </div>
                      </Step>
                    )}

                    {step === 3 && (
                      <Step
                        title="Inspiration & assets"
                        hint="Share examples you love and any files we should work with."
                      >
                        <div className="space-y-6">
                          <TextArea
                            label="Websites you love (paste links)"
                            value={data.inspiration}
                            onChange={(v) => set({ inspiration: v })}
                            placeholder="https://example.com — love the hero&#10;https://another.com — clean pricing"
                          />

                          <Group label="Upload logo, photos or brand files">
                            <div
                              onDragOver={(e) => {
                                e.preventDefault();
                                setDragOver(true);
                              }}
                              onDragLeave={() => setDragOver(false)}
                              onDrop={(e) => {
                                e.preventDefault();
                                setDragOver(false);
                                addFiles(e.dataTransfer.files);
                              }}
                              onClick={() => fileInput.current?.click()}
                              className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-10 text-center transition-colors ${
                                dragOver
                                  ? "border-cyan bg-cyan/5"
                                  : "border-white/15 hover:border-white/30"
                              }`}
                            >
                              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/5">
                                <UploadCloud size={22} className="text-cyan" />
                              </span>
                              <p className="mt-3 text-sm text-mist">
                                Drag & drop files here, or{" "}
                                <span className="text-cyan">browse</span>
                              </p>
                              <p className="mt-1 text-xs text-muted">
                                Images, PDFs and docs welcome
                              </p>
                              <input
                                ref={fileInput}
                                type="file"
                                multiple
                                className="hidden"
                                onChange={(e) => addFiles(e.target.files)}
                              />
                            </div>

                            {data.files.length > 0 && (
                              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                                {data.files.map((f) => (
                                  <div
                                    key={f.url}
                                    className="group relative overflow-hidden rounded-xl border border-white/10 bg-white/[0.03]"
                                  >
                                    {f.isImage ? (
                                      <img
                                        src={f.url}
                                        alt={f.name}
                                        className="h-24 w-full object-cover"
                                      />
                                    ) : (
                                      <div className="grid h-24 place-items-center text-xs text-muted">
                                        {f.name.split(".").pop()?.toUpperCase()}
                                      </div>
                                    )}
                                    <div className="flex items-center justify-between gap-1 px-2 py-1.5">
                                      <span className="truncate text-[11px] text-mist/80">
                                        {f.name}
                                      </span>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          removeFile(f.url);
                                        }}
                                        className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-black/50 text-white/70 hover:text-white"
                                      >
                                        <X size={12} />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </Group>

                          <TextArea
                            label="Anything else we should know?"
                            value={data.wishes}
                            onChange={(v) => set({ wishes: v })}
                            placeholder="Special features, deadlines, must-haves…"
                          />
                        </div>
                      </Step>
                    )}

                    {step === 4 && (
                      <Step
                        title="Your details"
                        hint="Where should we send your tailored proposal?"
                      >
                        <div className="space-y-5">
                          <Input
                            label="Your name"
                            value={data.contactName}
                            onChange={(v) => set({ contactName: v })}
                            placeholder="Jane Doe"
                          />
                          <div className="grid gap-5 sm:grid-cols-2">
                            <Input
                              label="Email"
                              type="email"
                              value={data.email}
                              onChange={(v) => set({ email: v })}
                              placeholder="you@business.com"
                            />
                            <Input
                              label="Phone (optional)"
                              value={data.phone}
                              onChange={(v) => set({ phone: v })}
                              placeholder="+31 6 …"
                            />
                          </div>

                          <Summary data={data} />
                        </div>
                      </Step>
                    )}
                  </motion.div>
                </AnimatePresence>

                {/* nav */}
                <div className="mt-8 flex items-center justify-between gap-3 border-t border-white/10 pt-6">
                  <button
                    onClick={() => (step === 0 ? navigate("/") : go(step - 1))}
                    className="flex items-center gap-1.5 text-sm text-muted transition-colors hover:text-mist"
                  >
                    <ArrowLeft size={15} /> Back
                  </button>

                  {step < STEPS.length - 1 ? (
                    <button
                      onClick={() => canContinue && go(step + 1)}
                      disabled={!canContinue}
                      className="btn-primary disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Continue <ArrowRight size={17} />
                    </button>
                  ) : (
                    <button
                      onClick={() => canContinue && submit()}
                      disabled={!canContinue}
                      className="btn-primary disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Submit project <CheckCircle2 size={18} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- small building blocks ---------- */

function Step({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h2 className="text-2xl font-semibold tracking-tightest">{title}</h2>
      {hint && <p className="mt-1.5 text-sm text-muted">{hint}</p>}
      <div className="mt-7">{children}</div>
    </div>
  );
}

function Group({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <p className="mb-3 text-sm font-medium text-mist">{label}</p>
      {children}
    </div>
  );
}

function ChipGroup({
  options,
  selected,
  onToggle,
}: {
  options: string[];
  selected: string[];
  onToggle: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => {
        const sel = selected.includes(o);
        return (
          <button
            key={o}
            onClick={() => onToggle(o)}
            className={`rounded-full border px-4 py-2 text-sm transition-all ${
              sel
                ? "border-cyan/60 bg-cyan/10 text-mist"
                : "border-white/10 text-muted hover:border-white/25 hover:text-mist"
            }`}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-muted">{label}</label>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-mist placeholder:text-muted/50 outline-none transition-colors focus:border-cyan/50 focus:bg-white/[0.07]"
      />
    </div>
  );
}

function TextArea({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-muted">{label}</label>
      <textarea
        rows={4}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-mist placeholder:text-muted/50 outline-none transition-colors focus:border-cyan/50 focus:bg-white/[0.07]"
      />
    </div>
  );
}

function Summary({ data }: { data: Data }) {
  const plan = PRICING.find((p) => p.id === data.plan);
  const rows: [string, string][] = [
    ["Package", `${plan?.name} · ${plan?.price}`],
    ["Business", data.businessName || "—"],
    ["Style", data.styles.join(", ") || "—"],
    ["Pages", data.pages.join(", ") || "—"],
    ["Files", data.files.length ? `${data.files.length} attached` : "none"],
  ];
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <p className="mb-3 text-sm font-medium text-mist">Quick summary</p>
      <dl className="space-y-2 text-sm">
        {rows.map(([k, v]) => (
          <div key={k} className="flex gap-3">
            <dt className="w-20 shrink-0 text-muted">{k}</dt>
            <dd className="text-mist/85">{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function Success({ name, onHome }: { name: string; onHome: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto max-w-lg pt-16 text-center"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
        className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-cyan to-electric shadow-glow"
      >
        <Check size={38} className="text-ink" />
      </motion.div>
      <h1 className="mt-8 font-display text-3xl font-semibold tracking-tightest sm:text-4xl">
        Thank you{name ? `, ${name.split(" ")[0]}` : ""}!
      </h1>
      <p className="mt-4 text-muted">
        Your project brief is on its way. We've opened your email so you can hit
        send — or reach us directly anytime. We typically reply within a day.
      </p>
      <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <a href={SITE.emailHref} className="btn-ghost">
          {SITE.email}
        </a>
        <button onClick={onHome} className="btn-primary">
          Back to homepage <ArrowRight size={17} />
        </button>
      </div>
    </motion.div>
  );
}
