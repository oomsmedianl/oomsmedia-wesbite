import { motion } from "framer-motion";
import { ShieldCheck, Rocket, HeartHandshake, Clock } from "lucide-react";
import { WHY } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

const ICONS = [ShieldCheck, Rocket, HeartHandshake, Clock];

export default function WhyChoose() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="Why Ooms Media"
          title={
            <>
              The difference is in the{" "}
              <span className="text-gradient-cyan">details</span>
            </>
          }
          subtitle="We treat every project like our own flagship. No templates, no outsourcing, no compromise on quality."
        />

        <Stagger className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {WHY.map((item, i) => {
            const Icon = ICONS[i];
            return (
              <motion.div
                key={item.label}
                variants={staggerItem}
                className="relative overflow-hidden rounded-3xl glass p-7"
              >
                <Icon size={20} className="text-cyan" />
                <p className="mt-5 font-display text-4xl font-semibold tracking-tightest text-gradient">
                  {item.stat}
                </p>
                <p className="mt-1 text-sm font-medium text-mist">{item.label}</p>
                <p className="mt-3 text-sm leading-relaxed text-muted">
                  {item.text}
                </p>
                <div className="pointer-events-none absolute -bottom-10 -right-10 h-28 w-28 rounded-full bg-cyan/10 blur-2xl" />
              </motion.div>
            );
          })}
        </Stagger>
      </div>
    </section>
  );
}
