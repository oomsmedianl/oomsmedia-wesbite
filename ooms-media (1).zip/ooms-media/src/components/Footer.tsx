import { Phone, Mail, MapPin } from "lucide-react";
import { NAV, SITE } from "../lib/site";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/10 py-14">
      <div className="container-x">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <img
              src="/assets/logo-full.png"
              alt={SITE.name}
              className="h-8 w-auto"
            />
            <p className="mt-5 text-sm leading-relaxed text-muted">
              Premium websites, branding and digital experiences for businesses
              that want to stand out. Proudly building from {SITE.area}.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:gap-16">
            <div>
              <p className="text-xs uppercase tracking-widest2 text-muted">
                Explore
              </p>
              <ul className="mt-4 space-y-2.5">
                {NAV.map((n) => (
                  <li key={n.href}>
                    <a
                      href={"/" + n.href}
                      className="text-sm text-mist/80 transition-colors hover:text-cyan"
                    >
                      {n.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest2 text-muted">
                Contact
              </p>
              <ul className="mt-4 space-y-2.5">
                <li>
                  <a
                    href={SITE.phoneHref}
                    className="flex items-center gap-2 text-sm text-mist/80 hover:text-cyan"
                  >
                    <Phone size={14} className="text-cyan" /> {SITE.phone}
                  </a>
                </li>
                <li>
                  <a
                    href={SITE.emailHref}
                    className="flex items-center gap-2 text-sm text-mist/80 hover:text-cyan"
                  >
                    <Mail size={14} className="text-cyan" /> {SITE.email}
                  </a>
                </li>
                <li className="flex items-center gap-2 text-sm text-mist/80">
                  <MapPin size={14} className="text-cyan" /> {SITE.area}
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-muted sm:flex-row">
          <p>
            © {new Date().getFullYear()} {SITE.name}. All rights reserved.
          </p>
          <p>Designed & built with care in Zeeland.</p>
        </div>
      </div>
    </footer>
  );
}
