import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { TESTIMONIALS } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

export default function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="Social proof"
          title={
            <>
              Businesses that took the{" "}
              <span className="text-gradient-cyan">leap</span>
            </>
          }
          subtitle="The reaction is almost always the same: relief that it finally looks the way it should."
        />

        <Stagger className="mt-16 grid gap-5 md:grid-cols-2" gap={0.1}>
          {TESTIMONIALS.map((t) => (
            <motion.figure
              key={t.name}
              variants={staggerItem}
              className="relative overflow-hidden rounded-3xl glass p-7"
            >
              <div className="flex items-center gap-1 text-cyan">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={15} className="fill-current" />
                ))}
              </div>
              <blockquote className="mt-4 text-lg leading-relaxed text-mist/90">
                "{t.quote}"
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-cyan/30 to-electric/20 font-display font-semibold text-mist">
                  {t.name.charAt(0)}
                </span>
                <div>
                  <p className="text-sm font-medium text-mist">{t.name}</p>
                  <p className="text-xs text-muted">{t.role}</p>
                </div>
              </figcaption>
              <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-electric/10 blur-2xl" />
            </motion.figure>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
