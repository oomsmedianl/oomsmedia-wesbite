import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Reveal } from "./ui/primitives";

export default function FinalCTA() {
  const navigate = useNavigate();
  return (
    <section className="relative px-5 pb-24 sm:pb-32">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-white/10 px-6 py-20 text-center sm:px-12">
          {/* glow field */}
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(80%_120%_at_50%_0%,rgba(47,107,255,0.35),transparent_60%)]" />
            <div className="absolute -bottom-24 left-1/2 h-72 w-[40rem] -translate-x-1/2 rounded-full bg-cyan/20 blur-[120px]" />
            <div className="absolute inset-0 bg-grid-faint bg-[size:54px_54px] [mask-image:radial-gradient(60%_60%_at_50%_50%,#000,transparent)]" />
          </div>

          <Reveal>
            <span className="eyebrow">Ready when you are</span>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="relative mx-auto mt-5 max-w-3xl text-4xl font-semibold leading-[1.03] tracking-tightest sm:text-6xl">
              Your competitors won't wait.{" "}
              <span className="text-gradient-cyan">Neither should you.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="relative mx-auto mt-6 max-w-xl text-base text-muted sm:text-lg">
              Start your project today and have a website you're genuinely proud
              of in a matter of days.
            </p>
          </Reveal>
          <Reveal delay={0.24}>
            <div className="relative mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                onClick={() => navigate("/intake?plan=business")}
                className="btn-primary w-full sm:w-auto"
              >
                Start Your Website <ArrowRight size={18} />
              </button>
              <a href="#work" className="btn-ghost w-full sm:w-auto">
                View Our Work
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
