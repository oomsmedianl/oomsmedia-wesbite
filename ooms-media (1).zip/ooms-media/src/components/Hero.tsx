import { useRef } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useMotionValue,
} from "framer-motion";
import { ArrowRight, Play, Star, Zap, Gauge } from "lucide-react";
import { TRUST_LOGOS } from "../lib/site";

export default function Hero({
  onPrimary,
  onSecondary,
}: {
  onPrimary: () => void;
  onSecondary: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const yMockup = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  // Mouse parallax
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 60, damping: 18 });
  const sy = useSpring(my, { stiffness: 60, damping: 18 });
  const onMove = (e: React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    mx.set((e.clientX - r.left - r.width / 2) / r.width);
    my.set((e.clientY - r.top - r.height / 2) / r.height);
  };
  const tX = (f: number) => useTransform(sx, (v) => v * f);
  const tY = (f: number) => useTransform(sy, (v) => v * f);

  return (
    <section
      ref={ref}
      onMouseMove={onMove}
      className="relative flex min-h-[100svh] items-center overflow-hidden pb-16 pt-28 sm:pt-32"
    >
      {/* Background layers */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(120%_80%_at_50%_-10%,rgba(47,107,255,0.22),transparent_60%)]" />
        <div className="absolute -left-40 top-10 h-[46rem] w-[46rem] rounded-full bg-electric/25 blur-[150px] animate-drift" />
        <div className="absolute -right-32 top-1/4 h-[40rem] w-[40rem] rounded-full bg-cyan/20 blur-[150px] animate-float-slow" />
        <div className="absolute inset-0 bg-grid-faint bg-[size:64px_64px] [mask-image:radial-gradient(80%_60%_at_50%_30%,#000,transparent)]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <motion.div style={{ opacity }} className="container-x relative">
        <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
          {/* Left copy */}
          <div className="text-center lg:text-left">
            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-mist/90"
            >
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan opacity-70" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan" />
              </span>
              Premium digital agency · Zeeland, NL
            </motion.span>

            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.08 }}
              className="mt-6 text-[2.7rem] font-semibold leading-[1.02] tracking-tightest sm:text-6xl lg:text-[4.2rem]"
            >
              Premium websites
              <br className="hidden sm:block" /> built to{" "}
              <span className="text-gradient-cyan">dominate</span> online.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.18 }}
              className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg lg:mx-0"
            >
              Modern websites, branding and digital experiences for businesses
              that want to stand out — designed to look unforgettable and
              engineered to convert.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.28 }}
              className="mt-9 flex flex-col items-center gap-3 sm:flex-row lg:justify-start"
            >
              <button onClick={onPrimary} className="btn-primary w-full sm:w-auto">
                Start Your Website <ArrowRight size={18} />
              </button>
              <button onClick={onSecondary} className="btn-ghost w-full sm:w-auto">
                <Play size={16} className="fill-current" /> View Our Work
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-9 flex items-center justify-center gap-4 lg:justify-start"
            >
              <div className="flex -space-x-2">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="h-8 w-8 rounded-full border border-white/20 bg-gradient-to-br from-navy-600 to-navy-800"
                  />
                ))}
              </div>
              <div className="text-left text-sm">
                <div className="flex items-center gap-1 text-cyan">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={13} className="fill-current" />
                  ))}
                </div>
                <p className="text-muted">Loved by local businesses</p>
              </div>
            </motion.div>
          </div>

          {/* Right floating mockup */}
          <motion.div
            style={{ y: yMockup }}
            className="relative mx-auto w-full max-w-md lg:max-w-none"
          >
            <motion.div
              initial={{ opacity: 0, y: 40, rotateX: 12 }}
              animate={{ opacity: 1, y: 0, rotateX: 0 }}
              transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              style={{ x: tX(-18), y: tY(-18) }}
              className="relative"
            >
              <BrowserMockup />
            </motion.div>

            {/* Floating chips */}
            <motion.div
              style={{ x: tX(38), y: tY(28) }}
              className="absolute -left-4 top-10 sm:-left-10"
            >
              <FloatChip
                icon={<Gauge size={16} className="text-cyan" />}
                title="PageSpeed"
                value="99 / 100"
                delay={0.6}
              />
            </motion.div>
            <motion.div
              style={{ x: tX(-30), y: tY(36) }}
              className="absolute -right-3 bottom-16 sm:-right-8"
            >
              <FloatChip
                icon={<Zap size={16} className="text-cyan" />}
                title="Conversions"
                value="+38%"
                delay={0.8}
              />
            </motion.div>
          </motion.div>
        </div>
      </motion.div>

      {/* Trust marquee */}
      <div className="absolute inset-x-0 bottom-5 hidden overflow-hidden md:block">
        <div className="container-x">
          <p className="mb-4 text-center text-[11px] uppercase tracking-widest2 text-muted/60">
            Trusted by ambitious brands
          </p>
        </div>
        <div className="relative flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_12%,#000_88%,transparent)]">
          <div className="flex shrink-0 animate-marquee items-center gap-16 pr-16">
            {[...TRUST_LOGOS, ...TRUST_LOGOS].map((l, i) => (
              <span
                key={i}
                className="whitespace-nowrap font-display text-lg font-medium tracking-wide text-mist/30"
              >
                {l}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FloatChip({
  icon,
  title,
  value,
  delay,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay }}
      className="glass-strong flex animate-float items-center gap-3 rounded-2xl px-4 py-3 shadow-glass"
    >
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/5">
        {icon}
      </span>
      <div>
        <p className="text-[10px] uppercase tracking-wider text-muted">{title}</p>
        <p className="font-mono text-sm text-mist">{value}</p>
      </div>
    </motion.div>
  );
}

function BrowserMockup() {
  return (
    <div className="glass-strong overflow-hidden rounded-3xl shadow-glass glow-cyan">
      {/* top bar */}
      <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
        <span className="h-3 w-3 rounded-full bg-white/15" />
        <span className="h-3 w-3 rounded-full bg-white/15" />
        <span className="h-3 w-3 rounded-full bg-white/15" />
        <div className="ml-3 flex-1">
          <div className="mx-auto h-5 w-2/3 rounded-md bg-white/5" />
        </div>
      </div>
      {/* mini site */}
      <div className="relative aspect-[4/3] overflow-hidden p-5">
        <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_30%_0%,rgba(47,107,255,0.3),transparent_60%)]" />
        <div className="relative flex items-center justify-between">
          <div className="h-3 w-16 rounded bg-white/20" />
          <div className="flex gap-2">
            <div className="h-2 w-8 rounded bg-white/10" />
            <div className="h-2 w-8 rounded bg-white/10" />
            <div className="h-5 w-12 rounded-full bg-gradient-to-r from-cyan to-electric" />
          </div>
        </div>
        <div className="relative mt-8 max-w-[78%] space-y-2.5">
          <div className="h-4 w-full rounded bg-white/20" />
          <div className="h-4 w-4/5 rounded bg-white/10" />
          <div className="h-2.5 w-3/5 rounded bg-white/10" />
          <div className="mt-3 flex gap-2">
            <div className="h-7 w-24 rounded-full bg-gradient-to-r from-cyan to-electric shadow-glow" />
            <div className="h-7 w-20 rounded-full border border-white/15" />
          </div>
        </div>
        <div className="relative mt-7 grid grid-cols-3 gap-3">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-16 rounded-xl border border-white/10 bg-white/[0.04]"
            />
          ))}
        </div>
      </div>
    </div>
  );
}
