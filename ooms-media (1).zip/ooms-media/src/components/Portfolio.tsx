import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { PORTFOLIO } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

/* Stylized site preview rendered with CSS (no external screenshots) */
function MiniSite({ hue, title }: { hue: string; title: string }) {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-br ${hue}`} />
      <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_30%_0%,rgba(255,255,255,0.10),transparent)]" />
      <div className="relative flex items-center justify-between px-5 py-4">
        <span className="font-display text-sm font-semibold text-white/90">
          {title}
        </span>
        <div className="flex gap-1.5">
          <span className="h-1.5 w-6 rounded bg-white/20" />
          <span className="h-1.5 w-6 rounded bg-white/20" />
          <span className="h-1.5 w-8 rounded-full bg-white/40" />
        </div>
      </div>
      <div className="relative px-5 pt-3">
        <div className="h-3 w-2/3 rounded bg-white/30" />
        <div className="mt-2 h-3 w-1/2 rounded bg-white/20" />
        <div className="mt-4 h-6 w-24 rounded-full bg-white/30" />
        <div className="mt-5 grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-10 rounded-lg bg-white/10" />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function Portfolio() {
  return (
    <section id="work" className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="Selected work"
          title={
            <>
              Websites that earn{" "}
              <span className="text-gradient-cyan">attention</span>
            </>
          }
          subtitle="A glimpse at the kind of digital presence we craft — built to win trust before a word is even read."
        />

        <Stagger className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PORTFOLIO.map((p) => (
            <motion.a
              key={p.title}
              href="#contact"
              variants={staggerItem}
              whileHover={{ y: -8 }}
              className="group relative block aspect-[4/3] overflow-hidden rounded-3xl border border-white/10 shadow-glass"
            >
              <MiniSite hue={p.hue} title={p.title} />
              <div className="absolute inset-0 flex items-end bg-gradient-to-t from-ink/90 via-ink/10 to-transparent p-5 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <div className="flex w-full items-center justify-between">
                  <div>
                    <p className="font-display text-lg font-semibold">
                      {p.title}
                    </p>
                    <p className="text-xs uppercase tracking-wider text-cyan">
                      {p.tag}
                    </p>
                  </div>
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-white text-ink">
                    <ArrowUpRight size={18} />
                  </span>
                </div>
              </div>
              <span className="absolute left-4 top-4 rounded-full bg-black/40 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-white/70 backdrop-blur transition-opacity group-hover:opacity-0">
                {p.tag}
              </span>
            </motion.a>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
