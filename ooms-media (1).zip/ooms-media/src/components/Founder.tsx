import { ArrowRight, Quote } from "lucide-react";
import { SITE } from "../lib/site";
import { Reveal } from "./ui/primitives";

export default function Founder() {
  return (
    <section className="relative overflow-hidden py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_60%_at_80%_50%,rgba(47,107,255,0.12),transparent)]" />
      <div className="container-x relative">
        <div className="grid items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          {/* Portrait */}
          <Reveal>
            <div className="relative mx-auto w-full max-w-sm">
              <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-tr from-electric/30 to-cyan/20 blur-2xl" />
              <div className="relative overflow-hidden rounded-[1.75rem] border border-white/10 shadow-glass">
                <img
                  src={SITE.founderPhoto}
                  alt={SITE.founder}
                  className="aspect-[4/5] w-full object-cover object-top"
                />
                {/* cinematic navy grade */}
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
                <div className="absolute inset-0 bg-electric/10 mix-blend-overlay" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="font-display text-xl font-semibold">
                    {SITE.founder}
                  </p>
                  <p className="text-sm text-cyan">Founder · Ooms Media</p>
                </div>
              </div>
              {/* floating signature chip */}
              <div className="glass-strong absolute -right-3 top-6 rounded-2xl px-4 py-3 shadow-glass sm:-right-6">
                <p className="font-mono text-xs text-muted">Based in</p>
                <p className="text-sm font-medium">{SITE.area}</p>
              </div>
            </div>
          </Reveal>

          {/* Copy */}
          <div>
            <Reveal>
              <span className="eyebrow">The founder</span>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-4 text-4xl font-semibold leading-[1.05] tracking-tightest sm:text-5xl">
                You work directly with the person{" "}
                <span className="text-gradient-cyan">building your site</span>.
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <div className="relative mt-7 max-w-xl">
                <Quote
                  size={34}
                  className="absolute -left-1 -top-3 text-electric/40"
                />
                <p className="relative pl-8 text-lg leading-relaxed text-mist/90">
                  I started Ooms Media because too many great local businesses
                  are held back by websites that don't do them justice. My
                  promise is simple: a site that looks like a brand twice your
                  size, built with care and delivered fast — no agencies, no
                  middlemen, just one obsessive eye on every pixel.
                </p>
              </div>
            </Reveal>
            <Reveal delay={0.24}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a href="#pricing" className="btn-primary">
                  Work with me <ArrowRight size={17} />
                </a>
                <a href="#contact" className="btn-ghost">
                  Ask a question
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
