import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { MoveHorizontal, ArrowRight } from "lucide-react";
import { SectionHeading } from "./ui/primitives";

/* ---------- Dated "before" mock ---------- */
function BeforeMock() {
  return (
    <div className="absolute inset-0 select-none bg-[#dfe3e6] text-[#222]">
      <div className="flex items-center justify-between bg-[#b22222] px-4 py-2.5">
        <span className="font-serif text-lg font-bold tracking-tight text-white">
          ★ MyBusiness2009
        </span>
        <span className="hidden gap-3 text-[11px] text-yellow-200 underline sm:flex">
          <span>Home</span>
          <span>About Us</span>
          <span>Contact</span>
          <span>Guestbook</span>
        </span>
      </div>
      <div className="bg-[#1d4f8b] py-1 text-center text-[10px] font-bold text-yellow-300">
        ✦ WELCOME TO OUR WEBSITE — BEST PRICES IN TOWN!!! ✦
      </div>
      <div className="grid grid-cols-3 gap-3 p-4">
        <div className="col-span-2 space-y-2">
          <p className="font-serif text-base font-bold text-[#b22222] underline">
            About Our Company
          </p>
          <div className="space-y-1.5">
            <div className="h-2 w-full rounded-sm bg-[#9aa0a6]" />
            <div className="h-2 w-full rounded-sm bg-[#9aa0a6]" />
            <div className="h-2 w-5/6 rounded-sm bg-[#9aa0a6]" />
            <div className="h-2 w-full rounded-sm bg-[#9aa0a6]" />
            <div className="h-2 w-2/3 rounded-sm bg-[#9aa0a6]" />
          </div>
          <div className="mt-3 inline-block border-2 border-[#888] bg-[#e8e8e8] px-3 py-1 text-[11px] font-bold text-[#333]">
            Click Here !!!
          </div>
        </div>
        <div className="space-y-2">
          <div className="grid h-20 place-items-center border-2 border-dashed border-[#999] bg-[#cfd4d8] text-[10px] text-[#777]">
            [ image.gif ]
          </div>
          <div className="bg-[#ffffcc] p-2 text-[9px] leading-tight text-[#660000]">
            Sign our guestbook! Visitors: 000142
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 w-full bg-[#333] py-1 text-center text-[9px] text-[#bbb]">
        © 2009 — Best viewed in 1024×768
      </div>
    </div>
  );
}

/* ---------- Premium "after" mock ---------- */
function AfterMock() {
  return (
    <div className="absolute inset-0 select-none overflow-hidden bg-ink text-mist">
      <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_25%_0%,rgba(47,107,255,0.35),transparent_60%)]" />
      <div className="relative flex items-center justify-between px-5 py-4">
        <span className="font-display text-base font-semibold">Atlas</span>
        <div className="hidden items-center gap-4 text-[11px] text-muted sm:flex">
          <span>Work</span>
          <span>Studio</span>
          <span className="rounded-full bg-gradient-to-r from-cyan to-electric px-3 py-1 text-ink">
            Book now
          </span>
        </div>
      </div>
      <div className="relative px-5 pt-6">
        <p className="font-display text-2xl font-semibold leading-tight sm:text-3xl">
          Move <span className="text-gradient-cyan">better</span>.<br />
          Train smarter.
        </p>
        <div className="mt-3 h-2 w-2/3 rounded bg-white/10" />
        <div className="mt-1.5 h-2 w-1/2 rounded bg-white/10" />
        <div className="mt-5 flex gap-2">
          <div className="rounded-full bg-gradient-to-r from-cyan to-electric px-4 py-2 text-[11px] font-medium text-ink shadow-glow">
            Start today
          </div>
          <div className="rounded-full border border-white/15 px-4 py-2 text-[11px]">
            Our plans
          </div>
        </div>
        <div className="mt-6 grid grid-cols-3 gap-3">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-16 rounded-2xl border border-white/10 bg-white/[0.05] backdrop-blur"
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Slider() {
  const [pos, setPos] = useState(52);
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const move = useCallback((clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const p = ((clientX - r.left) / r.width) * 100;
    setPos(Math.max(2, Math.min(98, p)));
  }, []);

  useEffect(() => {
    const up = () => (dragging.current = false);
    const mm = (e: MouseEvent) => dragging.current && move(e.clientX);
    const tm = (e: TouchEvent) =>
      dragging.current && move(e.touches[0].clientX);
    window.addEventListener("mouseup", up);
    window.addEventListener("mousemove", mm);
    window.addEventListener("touchend", up);
    window.addEventListener("touchmove", tm, { passive: true });
    return () => {
      window.removeEventListener("mouseup", up);
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("touchend", up);
      window.removeEventListener("touchmove", tm);
    };
  }, [move]);

  return (
    <div className="relative mx-auto max-w-4xl">
      {/* device glow */}
      <div className="absolute -inset-6 rounded-[2rem] bg-electric/20 blur-3xl" />
      <div
        ref={ref}
        className="relative aspect-[16/10] cursor-ew-resize overflow-hidden rounded-3xl border border-white/10 shadow-glass glow-cyan"
        onMouseDown={(e) => {
          dragging.current = true;
          move(e.clientX);
        }}
        onTouchStart={(e) => {
          dragging.current = true;
          move(e.touches[0].clientX);
        }}
      >
        {/* After (full) */}
        <AfterMock />
        {/* Before (clipped) */}
        <div
          className="absolute inset-0"
          style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
        >
          <BeforeMock />
        </div>

        {/* Labels */}
        <span className="pointer-events-none absolute left-3 top-3 z-10 rounded-full bg-black/55 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-white/80 backdrop-blur">
          Before
        </span>
        <span className="pointer-events-none absolute right-3 top-3 z-10 rounded-full bg-gradient-to-r from-cyan/80 to-electric/80 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-ink backdrop-blur">
          After · Ooms Media
        </span>

        {/* Handle */}
        <div
          className="absolute inset-y-0 z-20 flex w-px items-center justify-center bg-white/80"
          style={{ left: `${pos}%` }}
        >
          <button
            aria-label="Drag to compare before and after"
            role="slider"
            aria-valuenow={Math.round(pos)}
            aria-valuemin={0}
            aria-valuemax={100}
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "ArrowLeft") setPos((p) => Math.max(2, p - 4));
              if (e.key === "ArrowRight") setPos((p) => Math.min(98, p + 4));
            }}
            onMouseDown={() => (dragging.current = true)}
            onTouchStart={() => (dragging.current = true)}
            className="grid h-11 w-11 -translate-x-1/2 place-items-center rounded-full bg-white text-ink shadow-glow ring-4 ring-white/20 focus:outline-none focus:ring-cyan/50"
          >
            <MoveHorizontal size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function BeforeAfter() {
  return (
    <section className="relative overflow-hidden py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_50%_40%,rgba(47,107,255,0.10),transparent)]" />
      <div className="container-x relative">
        <SectionHeading
          eyebrow="Before / After"
          title={
            <>
              From forgettable to{" "}
              <span className="text-gradient-cyan">flagship</span>
            </>
          }
          subtitle="Drag the handle and watch an outdated website transform into a premium experience. This is the kind of leap we build for every client."
        />

        <div className="mt-14">
          <Slider />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-10 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-center"
        >
          {[
            ["Bounce rate", "−47%"],
            ["Load time", "0.9s"],
            ["Mobile score", "98"],
          ].map(([label, value]) => (
            <div key={label}>
              <p className="font-display text-2xl font-semibold text-gradient-cyan">
                {value}
              </p>
              <p className="text-xs uppercase tracking-wider text-muted">
                {label}
              </p>
            </div>
          ))}
          <a
            href="#pricing"
            className="inline-flex items-center gap-1.5 text-sm text-cyan transition-colors hover:text-cyan-soft"
          >
            Transform mine <ArrowRight size={15} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
