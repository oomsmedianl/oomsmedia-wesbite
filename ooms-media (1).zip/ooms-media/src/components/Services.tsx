import { motion } from "framer-motion";
import {
  MonitorSmartphone,
  Sparkles,
  Wand2,
  TrendingUp,
  Check,
  type LucideIcon,
} from "lucide-react";
import { SERVICES } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

const ICONS: Record<string, LucideIcon> = {
  MonitorSmartphone,
  Sparkles,
  Wand2,
  TrendingUp,
};

export default function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="What we do"
          title={
            <>
              Everything you need to{" "}
              <span className="text-gradient-cyan">look unstoppable</span>
            </>
          }
          subtitle="Design, build and brand under one roof — a single team obsessed with making your business impossible to overlook."
        />

        <Stagger className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s) => {
            const Icon = ICONS[s.icon];
            return (
              <motion.article
                key={s.id}
                variants={staggerItem}
                whileHover={{ y: -6 }}
                className="group relative overflow-hidden rounded-3xl glass p-6 transition-colors duration-300 hover:border-cyan/30"
              >
                <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-electric/20 blur-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                <div className="relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-cyan/20 to-electric/10 ring-1 ring-white/10">
                  <Icon size={22} className="text-cyan" />
                </div>
                <h3 className="relative mt-6 text-xl font-semibold">{s.title}</h3>
                <p className="relative mt-3 text-sm leading-relaxed text-muted">
                  {s.description}
                </p>
                <ul className="relative mt-5 space-y-2">
                  {s.points.map((p) => (
                    <li key={p} className="flex items-center gap-2 text-sm text-mist/80">
                      <Check size={14} className="shrink-0 text-cyan" />
                      {p}
                    </li>
                  ))}
                </ul>
              </motion.article>
            );
          })}
        </Stagger>
      </div>
    </section>
  );
}
