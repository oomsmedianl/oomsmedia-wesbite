import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Check, ArrowRight, Sparkles } from "lucide-react";
import { PRICING } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

export default function Pricing() {
  const navigate = useNavigate();
  return (
    <section id="pricing" className="relative overflow-hidden py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,rgba(47,107,255,0.12),transparent)]" />
      <div className="container-x relative">
        <SectionHeading
          eyebrow="Pricing"
          title={
            <>
              Premium work,{" "}
              <span className="text-gradient-cyan">honest pricing</span>
            </>
          }
          subtitle="Transparent starting prices. Pick a direction below and tell us about your project — you'll get a tailored quote, no surprises."
        />

        <Stagger
          className="mt-16 grid items-stretch gap-5 lg:grid-cols-3"
          gap={0.12}
        >
          {PRICING.map((tier) => (
            <motion.div
              key={tier.id}
              variants={staggerItem}
              whileHover={{ y: -8 }}
              className={`relative flex flex-col rounded-3xl p-7 ${
                tier.featured
                  ? "glass-strong shadow-glow-blue ring-1 ring-cyan/30"
                  : "glass"
              }`}
            >
              {tier.featured && (
                <span className="absolute -top-3 left-1/2 inline-flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gradient-to-r from-cyan to-electric px-4 py-1 text-xs font-medium text-ink">
                  <Sparkles size={13} /> Most popular
                </span>
              )}
              <div className="flex items-baseline justify-between">
                <h3 className="font-display text-xl font-semibold">
                  {tier.name}
                </h3>
              </div>
              <p className="mt-1 text-sm text-muted">{tier.tagline}</p>

              <div className="mt-6 flex items-end gap-1">
                <span
                  className={`font-display text-4xl font-semibold tracking-tightest ${
                    tier.featured ? "text-gradient-cyan" : "text-mist"
                  }`}
                >
                  {tier.price}
                </span>
              </div>
              <div className="my-6 h-px w-full bg-white/10" />

              <ul className="flex-1 space-y-3">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-cyan/15">
                      <Check size={11} className="text-cyan" />
                    </span>
                    <span className="text-mist/85">{f}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => navigate(`/intake?plan=${tier.id}`)}
                className={`mt-8 ${
                  tier.featured ? "btn-primary" : "btn-ghost"
                } w-full`}
              >
                {tier.cta} <ArrowRight size={17} />
              </button>
            </motion.div>
          ))}
        </Stagger>

        <p className="mt-8 text-center text-sm text-muted">
          Not sure which fits?{" "}
          <a href="#contact" className="text-cyan hover:text-cyan-soft">
            Tell us about your project
          </a>{" "}
          and we'll point you the right way.
        </p>
      </div>
    </section>
  );
}
