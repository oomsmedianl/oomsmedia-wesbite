import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, ArrowRight, Check } from "lucide-react";
import { SITE } from "../lib/site";
import { Reveal } from "./ui/primitives";

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const body = encodeURIComponent(
      `Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`
    );
    window.location.href = `${SITE.emailHref}?subject=New project enquiry&body=${body}`;
    setSent(true);
  };

  const info = [
    { icon: Phone, label: "Call", value: SITE.phone, href: SITE.phoneHref },
    { icon: Mail, label: "Email", value: SITE.email, href: SITE.emailHref },
    { icon: MapPin, label: "Service area", value: SITE.area, href: null },
  ];

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="container-x">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Left */}
          <div>
            <Reveal>
              <span className="eyebrow">Get in touch</span>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-4 text-4xl font-semibold leading-[1.05] tracking-tightest sm:text-5xl">
                Let's build something{" "}
                <span className="text-gradient-cyan">worth showing off</span>.
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
                Tell us about your business and what you have in mind. We reply
                personally — usually within a day.
              </p>
            </Reveal>

            <Reveal delay={0.24}>
              <div className="mt-10 space-y-3">
                {info.map((item) => {
                  const Inner = (
                    <>
                      <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/5 ring-1 ring-white/10">
                        <item.icon size={18} className="text-cyan" />
                      </span>
                      <div>
                        <p className="text-xs uppercase tracking-wider text-muted">
                          {item.label}
                        </p>
                        <p className="text-mist">{item.value}</p>
                      </div>
                    </>
                  );
                  return item.href ? (
                    <a
                      key={item.label}
                      href={item.href}
                      className="flex items-center gap-4 rounded-2xl glass p-4 transition-colors hover:border-cyan/30"
                    >
                      {Inner}
                    </a>
                  ) : (
                    <div
                      key={item.label}
                      className="flex items-center gap-4 rounded-2xl glass p-4"
                    >
                      {Inner}
                    </div>
                  );
                })}
              </div>
            </Reveal>
          </div>

          {/* Form */}
          <Reveal delay={0.1}>
            <form
              onSubmit={submit}
              className="glass-strong rounded-3xl p-7 shadow-glass sm:p-9"
            >
              <div className="space-y-5">
                <Field
                  label="Your name"
                  value={form.name}
                  onChange={(v) => setForm({ ...form, name: v })}
                  placeholder="Jane Doe"
                />
                <Field
                  label="Email"
                  type="email"
                  value={form.email}
                  onChange={(v) => setForm({ ...form, email: v })}
                  placeholder="you@business.com"
                />
                <div>
                  <label className="mb-2 block text-sm text-muted">
                    What do you need?
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) =>
                      setForm({ ...form, message: e.target.value })
                    }
                    placeholder="A new website for my..."
                    className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-mist placeholder:text-muted/50 outline-none transition-colors focus:border-cyan/50 focus:bg-white/[0.07]"
                  />
                </div>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="btn-primary w-full"
                >
                  {sent ? (
                    <>
                      Opening your email <Check size={18} />
                    </>
                  ) : (
                    <>
                      Send enquiry <ArrowRight size={18} />
                    </>
                  )}
                </motion.button>
                <p className="text-center text-xs text-muted">
                  Prefer a full brief?{" "}
                  <a href="/intake?plan=business" className="text-cyan">
                    Use the project intake
                  </a>
                </p>
              </div>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-muted">{label}</label>
      <input
        required
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-mist placeholder:text-muted/50 outline-none transition-colors focus:border-cyan/50 focus:bg-white/[0.07]"
      />
    </div>
  );
}
