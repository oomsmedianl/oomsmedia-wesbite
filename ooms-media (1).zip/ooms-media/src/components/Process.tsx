import { motion } from "framer-motion";
import { PROCESS } from "../lib/site";
import { SectionHeading, Stagger, staggerItem } from "./ui/primitives";

export default function Process() {
  return (
    <section id="process" className="relative py-24 sm:py-32">
      <div className="container-x">
        <SectionHeading
          eyebrow="The process"
          title={
            <>
              A premium build, made{" "}
              <span className="text-gradient-cyan">effortless</span>
            </>
          }
          subtitle="Four clear steps from first hello to launch day — designed so you always know exactly what's happening."
        />

        <div className="relative mt-16">
          {/* connecting line */}
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-gradient-to-r from-transparent via-white/15 to-transparent lg:block" />
          <Stagger className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4" gap={0.12}>
            {PROCESS.map((p) => (
              <motion.div key={p.step} variants={staggerItem} className="relative">
                <div className="relative z-10 grid h-14 w-14 place-items-center rounded-2xl glass-strong font-mono text-cyan shadow-glow">
                  {p.step}
                </div>
                <h3 className="mt-6 text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  {p.text}
                </p>
              </motion.div>
            ))}
          </Stagger>
        </div>
      </div>
    </section>
  );
}
