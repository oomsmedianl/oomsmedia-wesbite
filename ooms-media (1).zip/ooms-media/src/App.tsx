import { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Intake from "./pages/Intake";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    // Only force scroll-to-top on real route changes (not in-page hash nav).
    if (!window.location.hash) {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  }, [pathname]);
  return null;
}

export default function App() {
  const { pathname } = useLocation();
  const isIntake = pathname.startsWith("/intake");

  return (
    <div className="min-h-screen bg-ink text-mist antialiased selection:bg-cyan/30">
      <ScrollToTop />
      {!isIntake && <Navbar />}
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/intake" element={<Intake />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      {!isIntake && <Footer />}
    </div>
  );
}
