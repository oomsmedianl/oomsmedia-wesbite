export const SITE = {
  name: "Ooms Media",
  founder: "Juriaan Ooms",
  phone: "+31 6 22576578",
  phoneHref: "tel:+31622576578",
  email: "oomsmedianl@gmail.com",
  emailHref: "mailto:oomsmedianl@gmail.com",
  area: "Zeeland, Netherlands",
  logo: "/assets/ooms-logo.png",
  founderPhoto: "/assets/founder.jpg",
};

export const NAV = [
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Pricing", href: "#pricing" },
  { label: "Process", href: "#process" },
  { label: "Contact", href: "#contact" },
];

export type Service = {
  id: string;
  title: string;
  description: string;
  points: string[];
  icon: string; // lucide name handled in component
};

export const SERVICES: Service[] = [
  {
    id: "websites",
    title: "Premium Websites",
    description:
      "Conversion-focused websites designed pixel-by-pixel and engineered to load fast, rank well and turn visitors into customers.",
    points: ["Custom design", "Mobile-first build", "Speed & SEO baked in"],
    icon: "MonitorSmartphone",
  },
  {
    id: "branding",
    title: "Brand Identity",
    description:
      "A cohesive visual system — logo, palette, type and voice — that makes your business look like the market leader it deserves to be.",
    points: ["Logo & identity", "Design system", "Brand guidelines"],
    icon: "Sparkles",
  },
  {
    id: "experiences",
    title: "Digital Experiences",
    description:
      "Motion, micro-interactions and interactive sections that make people feel something the moment they land on your site.",
    points: ["Cinematic motion", "Interactive UI", "Custom animations"],
    icon: "Wand2",
  },
  {
    id: "growth",
    title: "Booking & Growth",
    description:
      "Integrated booking systems, lead capture and analytics so your website doesn't just look good — it works for your bottom line.",
    points: ["Booking systems", "Lead funnels", "Analytics setup"],
    icon: "TrendingUp",
  },
];

export const WHY = [
  {
    stat: "100%",
    label: "Custom built",
    text: "No templates, no shortcuts. Every site is designed from a blank canvas around your brand.",
  },
  {
    stat: "<1.5s",
    label: "Load time target",
    text: "Engineered for speed so visitors never wait — and Google rewards you for it.",
  },
  {
    stat: "1-on-1",
    label: "Founder-led",
    text: "You work directly with the person building your site. No account managers, no hand-offs.",
  },
  {
    stat: "7–14d",
    label: "Typical delivery",
    text: "A premium website live in days, not months — without cutting a single corner.",
  },
];

export const PROCESS = [
  {
    step: "01",
    title: "Discovery",
    text: "We start with your intake. Your goals, audience and style come together into a clear creative direction.",
  },
  {
    step: "02",
    title: "Design",
    text: "You receive a cinematic, fully custom design concept — built around your brand, ready to react to.",
  },
  {
    step: "03",
    title: "Build",
    text: "Hand-coded for speed and polish. Animations, responsiveness and SEO are engineered in from day one.",
  },
  {
    step: "04",
    title: "Launch",
    text: "We deploy, test on every device and hand over a site you're proud to send to anyone.",
  },
];

export const PRICING = [
  {
    id: "starter",
    name: "Starter",
    price: "Vanaf €149",
    tagline: "A sharp one-page presence",
    featured: false,
    features: [
      "1-page premium website",
      "Mobile-first responsive design",
      "Contact form & socials",
      "Basic SEO setup",
      "Live in ~7 days",
    ],
    cta: "Start Starter",
  },
  {
    id: "business",
    name: "Business",
    price: "Vanaf €349",
    tagline: "The complete business website",
    featured: true,
    features: [
      "Up to 5 custom pages",
      "Custom animations & motion",
      "Brand styling & assets",
      "Advanced SEO & speed tuning",
      "Booking or lead system",
      "Priority delivery",
    ],
    cta: "Start Business",
  },
  {
    id: "premium",
    name: "Premium",
    price: "Vanaf €599",
    tagline: "Flagship brand experience",
    featured: false,
    features: [
      "Unlimited core pages",
      "Cinematic, fully bespoke design",
      "Full brand identity",
      "Integrations & automations",
      "Copywriting support",
      "30 days aftercare",
    ],
    cta: "Start Premium",
  },
];

export const PORTFOLIO = [
  { title: "Lumen Studio", tag: "Architecture", hue: "from-cyan/30 to-electric/20" },
  { title: "Atlas Fitness", tag: "Health & Sport", hue: "from-electric/30 to-cyan/10" },
  { title: "Noord Catering", tag: "Hospitality", hue: "from-cyan/20 to-electric/30" },
  { title: "Vega Dental", tag: "Healthcare", hue: "from-electric/20 to-cyan/20" },
  { title: "Kade 7", tag: "Restaurant", hue: "from-cyan/30 to-electric/10" },
  { title: "Stormveld", tag: "Real Estate", hue: "from-electric/30 to-cyan/20" },
];

export const TESTIMONIALS = [
  {
    quote:
      "We went from an outdated site we were embarrassed by to something that genuinely closes clients for us. The difference is night and day.",
    name: "Mark de Vries",
    role: "Owner, De Vries Bouw",
  },
  {
    quote:
      "Fast, professional and the result looks like a brand ten times our size. People constantly compliment the website.",
    name: "Lisa Janssen",
    role: "Founder, Studio Lisa",
  },
  {
    quote:
      "The whole process felt premium. Clear communication, a stunning design, and it was live faster than I expected.",
    name: "Tom Bakker",
    role: "Director, Bakker Advies",
  },
  {
    quote:
      "Our bookings noticeably went up after launch. This wasn't just a redesign — it was an upgrade to the whole business.",
    name: "Sophie Visser",
    role: "Owner, Salon Visser",
  },
];

export const TRUST_LOGOS = [
  "BOUW & CO",
  "STUDIO LISA",
  "KADE 7",
  "ATLAS",
  "VEGA",
  "STORMVELD",
  "NOORD",
];
