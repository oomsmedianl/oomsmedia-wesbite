# Ooms Media — Premium Agency Website

A production-ready marketing site for **Ooms Media**, built with Vite + React + TypeScript + TailwindCSS. Cinematic deep-navy / electric-cyan aesthetic, glassmorphism, scroll & hover motion (Framer Motion), a draggable before/after slider, and a fully functional multi-step client intake flow.

## Tech stack

- **Vite 5** + **React 18** + **TypeScript** (strict)
- **TailwindCSS 3.4** with a custom design-token theme
- **Framer Motion** for animation
- **React Router** for the Home + Intake routes
- **lucide-react** icons

## Getting started

```bash
npm install
npm run dev      # local dev server at http://localhost:5173
npm run build    # type-check + production build to /dist
npm run preview  # serve the production build locally
```

Node 18+ recommended (built and verified on Node 22).

## Project structure

```
src/
  components/        # Navbar, Hero, Services, BeforeAfter, Pricing, Founder, etc.
    ui/primitives.tsx  # Reveal, Stagger, Aurora, SectionHeading
  pages/
    Home.tsx         # all landing sections, in order
    Intake.tsx       # 5-step intake form (/intake?plan=starter|business|premium)
  lib/site.ts        # ALL editable content: contact info, pricing, copy, services
  App.tsx            # routes + conditional navbar/footer
  index.css          # Tailwind layers + component classes (.glass, .btn-primary, …)
public/assets/       # logo + founder image
```

## Editing content

Almost everything you'll want to change lives in **`src/lib/site.ts`** — business
name, phone, email, service area, the three pricing tiers, services, portfolio
items, and testimonials.

- **Contact details** are in the `SITE` object.
- **Pricing** (`Vanaf €149 / €349 / €599`) is in the `PRICING` array; the Business
  tier is flagged `featured`.
- **Portfolio** and **Testimonials** entries are placeholder content — replace the
  names, quotes, and project descriptions with real client work when you have it.

The founder name was inferred as **"Juriaan Ooms"** from the uploaded photo's
filename — change `SITE.founder` if that's not right.

## How the intake form works

The pricing buttons route to `/intake?plan=<tier>`. The form collects business
details, style/colour preferences, pages, inspiration links, and drag-and-drop
file uploads, then opens the visitor's mail client with a pre-filled brief to
`oomsmedianl@gmail.com` (via `mailto:`). The same applies to the quick contact
form. No backend is required to deploy.

> To capture submissions automatically instead of via the user's email client,
> wire the submit handlers in `src/pages/Intake.tsx` and `src/components/Contact.tsx`
> to a form backend such as Formspree, Resend, or your own API endpoint.

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. In Vercel, **Add New → Project** and import the repo.
3. Framework preset: **Vite**. Build command `npm run build`, output dir `dist`
   (Vercel detects these automatically). `vercel.json` already rewrites all routes
   to `index.html` so `/intake` works on refresh.
4. Deploy.

## Deploy via GitHub Pages / Netlify

Any static host works — serve the contents of `dist/` after `npm run build`.
Ensure SPA fallback (all routes → `index.html`) is configured, as in `vercel.json`.
