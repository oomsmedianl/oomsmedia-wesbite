/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#04070f",
        navy: {
          950: "#050914",
          900: "#060a16",
          800: "#0a1124",
          700: "#0f1830",
          600: "#16234a",
        },
        cyan: { DEFAULT: "#2fe3ff", soft: "#7df0ff" },
        electric: { DEFAULT: "#2f6bff", deep: "#1c47c7" },
        mist: "#e9f0ff",
        muted: "#8aa0c9",
      },
      fontFamily: {
        display: ['"Clash Display"', "system-ui", "sans-serif"],
        sans: ['"Satoshi"', "system-ui", "sans-serif"],
        mono: ['"JetBrains Mono"', "ui-monospace", "monospace"],
      },
      letterSpacing: {
        tightest: "-0.04em",
        widest2: "0.32em",
      },
      backgroundImage: {
        "grid-faint":
          "linear-gradient(to right, rgba(120,160,255,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(120,160,255,0.05) 1px, transparent 1px)",
      },
      boxShadow: {
        glow: "0 0 60px -12px rgba(47,227,255,0.45)",
        "glow-blue": "0 0 80px -16px rgba(47,107,255,0.55)",
        glass: "0 24px 80px -24px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.08)",
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0) rotate(0deg)" },
          "50%": { transform: "translateY(-14px) rotate(0.5deg)" },
        },
        "float-slow": {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(20px)" },
        },
        drift: {
          "0%": { transform: "translate3d(0,0,0) scale(1)" },
          "50%": { transform: "translate3d(40px,-30px,0) scale(1.08)" },
          "100%": { transform: "translate3d(0,0,0) scale(1)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "200% 0" },
          "100%": { backgroundPosition: "-200% 0" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        float: "float 7s ease-in-out infinite",
        "float-slow": "float-slow 10s ease-in-out infinite",
        drift: "drift 18s ease-in-out infinite",
        shimmer: "shimmer 3.5s linear infinite",
        marquee: "marquee 38s linear infinite",
      },
    },
  },
  plugins: [],
};
