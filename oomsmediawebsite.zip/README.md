# Ooms Media — Website

Premium homepage voor **Ooms Media**, webdesign studio uit Zeeland.

Dark navy · electric cyan · glassmorphism · cinematische animaties — volledig statisch gebouwd (HTML / CSS / JavaScript), dus razendsnel en zonder build-stap te hosten.

## Structuur

```
index.html        → de homepage
css/style.css     → volledig design system + alle secties
js/main.js        → animaties, mobiel menu, voor/na-slider, tellers
assets/           → logo's, founder-foto, social share afbeelding
```

## Lokaal bekijken

Open `index.html` in de browser, of start een mini-server:

```bash
python3 -m http.server 8000
# → http://localhost:8000
```

## Online zetten

**GitHub Pages (gratis):** Settings → Pages → Source: *Deploy from a branch* → branch `main`, map `/ (root)` → Save. De site staat binnen een minuut live.

**Vercel / Netlify:** importeer deze repository — geen build command nodig (statische site, output directory: root).

## Secties

1. Cinematische hero met zwevende UI-elementen
2. Trust-strip (marquee + kerncijfers)
3. Diensten (6 glass cards)
4. Voor/Na showcase met sleepbare vergelijking
5. Waarom Ooms Media
6. Over Juriaan Ooms
7. Prijzen (Starter / Premium / Ultimate — eenmalige vanaf-prijzen)
8. Call-to-action
9. Footer

## Contact

Juriaan Ooms · [oomsmedianl@gmail.com](mailto:oomsmedianl@gmail.com) · +31 6 22576578 · Zeeland, Nederland
