/* ═══════════════════════════════════════════════════════════════
   OOMS MEDIA — interactions
   ═══════════════════════════════════════════════════════════════ */
(() => {
  "use strict";

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ── Navbar: glass background after scrolling ─────────────── */
  const nav = document.getElementById("nav");
  const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 24);
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ── Mobile menu ──────────────────────────────────────────── */
  const burger = document.getElementById("navBurger");
  const menu = document.getElementById("mobileMenu");

  const setMenu = (open) => {
    burger.classList.toggle("open", open);
    menu.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Menu sluiten" : "Menu openen");
    menu.setAttribute("aria-hidden", String(!open));
    document.body.style.overflow = open ? "hidden" : "";
  };

  burger.addEventListener("click", () => setMenu(!burger.classList.contains("open")));
  menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setMenu(false)));
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && menu.classList.contains("open")) setMenu(false);
  });
  window.matchMedia("(min-width: 881px)").addEventListener("change", (e) => {
    if (e.matches) setMenu(false);
  });

  /* ── Scroll reveal ────────────────────────────────────────── */
  const revealEls = document.querySelectorAll("[data-reveal]");
  if (reducedMotion) {
    revealEls.forEach((el) => el.classList.add("is-visible"));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );
    revealEls.forEach((el) => revealObserver.observe(el));
  }

  /* ── Animated counters ────────────────────────────────────── */
  const counters = document.querySelectorAll("[data-count]");
  const runCounter = (el) => {
    const target = parseInt(el.dataset.count, 10) || 0;
    if (reducedMotion || target === 0) {
      el.textContent = String(target);
      return;
    }
    const duration = 1500;
    const start = performance.now();
    const tick = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      el.textContent = String(Math.round(target * eased));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          runCounter(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.6 }
  );
  counters.forEach((el) => counterObserver.observe(el));

  /* ── Before/after comparison slider ───────────────────────── */
  const compare = document.getElementById("compare");
  const handle = document.getElementById("compareHandle");

  if (compare && handle) {
    const frame = compare.querySelector(".compare__frame");
    let pos = 50;

    const setPos = (value) => {
      pos = Math.min(94, Math.max(6, value));
      compare.style.setProperty("--pos", pos + "%");
      handle.setAttribute("aria-valuenow", String(Math.round(pos)));
    };

    const posFromEvent = (e) => {
      const rect = frame.getBoundingClientRect();
      setPos(((e.clientX - rect.left) / rect.width) * 100);
    };

    let dragging = false;
    frame.addEventListener("pointerdown", (e) => {
      dragging = true;
      frame.setPointerCapture(e.pointerId);
      posFromEvent(e);
    });
    frame.addEventListener("pointermove", (e) => {
      if (dragging) posFromEvent(e);
    });
    const stopDrag = () => (dragging = false);
    frame.addEventListener("pointerup", stopDrag);
    frame.addEventListener("pointercancel", stopDrag);

    handle.addEventListener("keydown", (e) => {
      const step = e.shiftKey ? 10 : 4;
      if (e.key === "ArrowLeft") {
        setPos(pos - step);
        e.preventDefault();
      } else if (e.key === "ArrowRight") {
        setPos(pos + step);
        e.preventDefault();
      }
    });

    // small intro nudge so visitors notice the slider is draggable
    if (!reducedMotion) {
      const nudgeObserver = new IntersectionObserver(
        (entries) => {
          if (!entries[0].isIntersecting) return;
          nudgeObserver.disconnect();
          let t = 0;
          const nudge = () => {
            t += 1 / 60;
            if (dragging || t > 1.6) return;
            setPos(50 + Math.sin(t * Math.PI) * 7);
            requestAnimationFrame(nudge);
          };
          setTimeout(() => requestAnimationFrame(nudge), 500);
        },
        { threshold: 0.5 }
      );
      nudgeObserver.observe(compare);
    }
  }

  /* ── Card cursor spotlight ────────────────────────────────── */
  if (window.matchMedia("(pointer: fine)").matches) {
    document.querySelectorAll(".card").forEach((card) => {
      card.addEventListener("pointermove", (e) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty("--mx", e.clientX - rect.left + "px");
        card.style.setProperty("--my", e.clientY - rect.top + "px");
      });
    });
  }

  /* ── Hero watermark mouse parallax ────────────────────────── */
  const parallaxEls = document.querySelectorAll("[data-parallax]");
  if (parallaxEls.length && !reducedMotion && window.matchMedia("(pointer: fine)").matches) {
    let raf = null;
    window.addEventListener(
      "pointermove",
      (e) => {
        if (raf) return;
        raf = requestAnimationFrame(() => {
          const dx = e.clientX / window.innerWidth - 0.5;
          const dy = e.clientY / window.innerHeight - 0.5;
          parallaxEls.forEach((el) => {
            const depth = parseFloat(el.dataset.parallax) || 10;
            el.style.setProperty("--px", (-dx * depth).toFixed(1) + "px");
            el.style.setProperty("--py", (-dy * depth).toFixed(1) + "px");
          });
          raf = null;
        });
      },
      { passive: true }
    );
  }

  /* ── Footer year ──────────────────────────────────────────── */
  const year = document.getElementById("year");
  if (year) year.textContent = String(new Date().getFullYear());
})();
